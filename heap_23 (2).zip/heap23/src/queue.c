#include "..\include\queue.h"
#include "..\include\task.h"
#include <stdio.h>
#include <malloc.h>




struct queue* create_queue()
{
	struct queue* q = (struct queue*)malloc(sizeof(struct queue));
	q->front = NULL;
	q->rear = NULL;
	return q;
}

struct node* create_node()
{
	struct node* new_node = (struct node*)malloc(sizeof(struct node));
	new_node->task = NULL; 
	new_node->next = NULL; 
	return new_node;
}
void enqueue(struct queue* q, struct task* t)
{
	//printf("\n LIne 21, queue.c, task.pages = %d", t->pages);
	if (is_empty(q)) {
		q->front = create_node();
		q->front->task = t;
		//q->front->next = q->rear;
	}
	else {
		if (q->rear == NULL) {
			q->rear = create_node();
			q->rear->task = t;
			q->front->next = q->rear;
		}
		else {
			struct node* n = create_node();
			n->task = t;
			q->rear->next = n;
			q->rear = n;
		}
	}
}





struct task* dequeue(struct queue* q)
{
	if (is_empty(q)) {
		printf("\n The queue is empty");
		return NULL;
	}
	else {
		struct node* temp = q->front;
		q->front = q->front->next;
		struct task* t = temp->task;
		//free(temp);
		return t;
	}
}


void display_queue(struct queue* q)
{
	printf("\n TASKS IN QUE: ");
	if (is_empty(q)) {
		printf("\n The queue is empty");
	}
	else {
		struct node* n = q->front;
		int i = 1;
		while (n != NULL)
		{
			printf("\n TASK ");
			printf(" [ arrives at %d second, %d pages ]",  n->task->time_stamp % 100, n->task->pages);
			n = n->next;
			i++;
		}
	}
}
 
int is_empty(struct queue* q)
{
	if (q->front == NULL) {
		return 1;
	}
	else {
		return 0;
	}
}





