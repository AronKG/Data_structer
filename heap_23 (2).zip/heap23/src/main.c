// Aron Kesete
#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
//#include <malloc.h>
#include <time.h>

#include "..\include\printer.h"
#include "..\include\task.h"
#include "..\include\queue.h"




struct printer create_printer() {
	struct printer p;
	p.current_task = NULL; // t; 
	p.page_rate = (60 / 40);
	p.time_remaining = 0;

	return p;
}

void new_task_to_que(struct queue* q, int ct) {
	struct task* t = create_task(ct);
	enqueue(q, t);
}

void printing(struct printer p, struct queue* q, int ct, int* stop) {
	while (p.time_remaining > 0) {
		printer_status(&p);
		printf("\n %d seconds to complete the current task.", p.time_remaining);
		tick(&p);
		if (p.time_remaining == 5 || p.time_remaining == 0) {
			new_task_to_que(q, ct);
		}
		display_queue(q);
		printf("\n");
		if (p.current_task->pages == 4 && p.time_remaining == 4) {
			*stop = 1;
			break;
		}
	}
	printer_status(&p);
	display_queue(q);
}

int main()
{
	time_t tt = time(NULL);
	int ct = (int)(tt);

	struct printer p = create_printer();
	struct queue* q = create_queue();

	int stop = 0;
	printer_status(&p);
	new_task_to_que(q, ct);
	display_queue(q);
	printf("\n");
	while (q->front != NULL && p.time_remaining >= 0) {
		start_next(&p, dequeue(q));
		printing(p, q, ct, &stop);
		if (stop == 1) {
			break;
		}
	}

	return 0;
}


