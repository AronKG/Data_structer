#include "..\include\printer.h"
#include <stdio.h>

#include "..\include\task.h"



//do one second of printing, 
//i.e., the remaning time to complete the current task is subtracted one. 
//parameters:
//  *p, the pointer points to the printer
void tick(struct printer* p)
{
    p->time_remaining -= 1;
}

//check whehter the printer is printing
//parameters:
//  *p, the pointer points to the printer
//return 1 (true) or 0 (false)
int is_busy(struct printer* p)
{
    if (p->time_remaining == 0) {
        return 0; 
    }
    else {
        return 1;
    }
}
//start the next printing task
//parameters:
//  *p, the pointer points to the printer
//  *t, the pointer points to the printing task
void start_next(struct printer* p, struct task* t)
{
    p->current_task = t;
    p->time_remaining = (60  * t->pages) / 40;
    tick(p);
}
//display the printer's current status
//  *p, the pointer points to the printer
void printer_status(struct printer* p)
{
    if (is_busy(p) == 0) {
        printf("\n THE PRINTER IS NO LONGER BUSY!");
    }
    else {
        printf("\n THE PRINTER IS BUSY!"); 
    }
}