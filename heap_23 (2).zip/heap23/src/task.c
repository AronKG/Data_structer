#include "..\include\task.h"
#include <malloc.h>


int j = 1, m = 5;
struct task* create_task(int ct)   // ct: seconds nu tiden  eg ct = den 15seconder ankommer
{
	srand(time(NULL));

	struct task* new_task = (struct task*)malloc(sizeof(struct task));
	new_task->pages = m;
	m--;
	new_task->time_stamp = ct + j;
	j += 3;
	return new_task;
}
//compute the waiting time for the task
//parameters:
//  *t, the pointer that points to the printing task
//  ct, the current time (in second)
//return:
//  the waiting time (in seconds)


int wait_time(struct task* t, int ct)  // nu tiden eg den anropas den 45 seconder
{
	// how many munites dose it takes.
	//int x = t->pages;  // number of seconds required to print the task   4pages, x = 6sseconds
	//int y = ct - t->time_stamp; // ct (current time in seconds) = 45 och time-stamp = 15 = 30


	return ct - t->time_stamp; 
}

