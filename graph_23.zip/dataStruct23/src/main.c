//Aron kesete 
//  The main function for the program to find the shortest path between cities.
//
//Written by He Tan, March 2022
#include <stdio.h>
#include <stdlib.h>
#include "..\include\heap.h"
#include "..\include\graph.h"
//#include <clocale>


//the number of nodes in the graph
#define GRAPH_NODE_N 7
#define INFINITY 9999


//the function that calculates the distances of shortest paths between cities
//parameters: source_node, the id of the source node
//            dist, the minimum distance
//            graph, the graph
void dijkstra(int source_node, int dist[], struct graph* graph);


int main(void)
{
    char* cities[GRAPH_NODE_N] = { "Jönköping", "Ulricehamn", "Värnamo", "Göteborg", "Helsingborg", "Ljungby", "Malmö" };

    struct graph* graph = createGraph(GRAPH_NODE_N);

    //0: Jönköping, 1: Ulricehamn, 2: Värnamo, 3: Göteborg, 4: Helsingborg, 5: Ljunby, 6: Malmö
    addEdge(graph, 0, 2, 2);
    addEdge(graph, 1, 0, 4);
    addEdge(graph, 3, 1, 15);
    addEdge(graph, 3, 5, 5);
    addEdge(graph, 3, 6, 23);
    addEdge(graph, 4, 1, 17);
    addEdge(graph, 4, 6, 11);
    addEdge(graph, 5, 2, 9);
    addEdge(graph, 5, 6, 13);

    displayGraph(graph, cities);

    int source_node;
    int choice; 
    printf("\nEnter 1 if you want to search a city and 0 to exit:  ");
    scanf("%d", &choice);
    while (choice == 1)
    {

    
        printf("\n0: Jönköping, 1: Ulricehamn, 2: Värnamo, 3: Göteborg, 4: Helsingborg, 5: Ljunby, 6: Malmö");
        printf("\nEnter the city number :  ");
        scanf("%d", &source_node);

        while (source_node > 6 || source_node < 0) {
            printf("Incorrect entry! please enter a valid city number");
            printf("\n0: Jönköping, 1: Ulricehamn, 2: Värnamo, 3: Göteborg, 4: Helsingborg, 5: Ljunby, 6: Malmö");
            printf("\nEnter the city number :  ");
            scanf("%d", &source_node);

        }

        //store the minimun distance
        int dist[GRAPH_NODE_N];
        dijkstra(source_node, dist, graph);

        printf("\nThe distance of the shortest path for travelling from %s to ", cities[source_node]);
        for (int i = 0; i < GRAPH_NODE_N; i++) {

            if (dist[i] == INFINITY)
                printf("\n%s !!! no connection between these two cities", cities[i]);
            else printf("\n%s is %d", cities[i], dist[i]);
        }
        printf("\n\nEnter 1 if you want to search a city and 0 to exit:  ");
        scanf("%d", &choice);

    }


    printf("\n");


    printf("end running c");

    return 0;
}


//the function that calculates the distances of shortest paths between cities
//parameters: source_node, the id of the source node
//            dist, the minimum distance
//            graph, the graph
void dijkstra(int source_node, int dist[], struct graph* graph)
{
    int visited[GRAPH_NODE_N];
    for (int i = 0; i < graph->N; i++)
    {
        visited[i] = 0;
        dist[i] = INFINITY;
        dist[source_node] = 0;
    }

    if (source_node >= 0 && source_node < graph->N)
    {
        dist[source_node] = 0;
    }
    else
    {
        printf("Invalid source node index.Need to check the array\n");
        return;
    }

    while (1)
    {
        int min_dist = INFINITY;
        int min_node = -1;
        for (int i = 0; i < graph->N; i++)
        {
            if (visited[i] == 0 && dist[i] < min_dist)
            {
                min_dist = dist[i];
                min_node = i;
            }
        }
        if (min_node == -1)
            break;
        visited[min_node] = 1;
        struct adjListNode* pCrawl = graph->array[min_node].head;
        while (pCrawl)
        {
            if (dist[pCrawl->graph_node_id] > dist[min_node] + pCrawl->weight)
            {
                dist[pCrawl->graph_node_id] = dist[min_node] + pCrawl->weight;
            }
            pCrawl = pCrawl->next;
        }
    }
}
