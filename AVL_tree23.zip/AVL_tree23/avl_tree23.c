// Aron Kesete

#include <stdio.h>
#include <math.h>

#define max(a,b) (((a) > (b)) ? (a) : (b))
typedef enum { FALSE, TRUE } bool;



struct node {
    int key;
    struct node* left;
    struct node* right;
    int balance;
};


int findHeight(struct node* root, int x)
{
    // Base Case
    if (root == NULL) {
        return -1;
    }
    int leftHeight = findHeight(root->left, x);
    int rightHeigt = findHeight(root->right, x);
   
    int ans = max(leftHeight, rightHeigt) + 1;
    //return 0;
    return ans;
}


struct node* search(struct node* ptr, int data) {
    if (ptr != NULL) {
        if (data < ptr->key) {
            ptr = search(ptr->left, data);
        }
        else if (data > ptr->key) {
            ptr = search(ptr->right, data);
        }
    }
    return ptr;
}

bool findElement(struct node* tree, int data) {
    if (tree == NULL) {
        return FALSE;
    }
    if (data < tree->key) {
        findElement(tree->left, data);
    }
    else if (data > tree->key) {
        findElement(tree->right, data);
    }
    else {
        return TRUE;
    }
}

struct node* findLargestElement(struct node* tree) {
    if (tree == NULL || tree->right == NULL) {
        return tree;
    }
    else {
        return findLargestElement(tree->right);
    }
}

struct node* deleteElement(struct node* tree, int data, bool* isKeyFound) {
    struct node* ptr, * pnext;
    *isKeyFound = findElement(tree, data);
    if (tree == NULL || !*isKeyFound) {
        return NULL;
    }
    else if (data < tree->key) {
        tree->left = deleteElement(tree->left, data, isKeyFound);
    }
    else if (data > tree->key) {
        tree->right = deleteElement(tree->right, data, isKeyFound);

        if (*isKeyFound == TRUE) {
            printf("Before switch tree = %d, balance = %d \n", tree->key, tree->balance);
            switch (tree->balance) {
            case -1:
                tree->balance = 0;
                break;
            case 0:
                tree->balance = 1;
                *isKeyFound = FALSE;
                break;
            case 1:
                ptr = tree->left;
                if (ptr->balance == 1) {
                    printf(" 80, in switch tree = %d, balance = %d\n", ptr->key, ptr->balance);
                    tree->left = ptr->right;
                    ptr->right = tree;
                    tree->balance = 0;
                    ptr->balance = 0;
                    printf(" 85, in switch tree = %d, balance = %d\n", tree->key, tree->balance);
                    tree = ptr;
                }
                else if (ptr->balance == 0) {
                    pnext = ptr->right;
                    if (pnext->balance == -1) {
                        tree->left = ptr->right;
                        ptr->right = tree;
                        tree->balance = 1;
                        ptr->balance = -1;
                        isKeyFound = FALSE;
                        tree = ptr;
                    }
                    else if (pnext->balance == 1) {
                        tree->left = pnext->right;
                        pnext->right = tree;
                        ptr->right = pnext->left;
                        pnext->left = ptr;
                        pnext->balance = 1;
                        tree->balance = -1;
                        ptr->balance = 1;
                        isKeyFound = FALSE;
                        tree = pnext;
                    }
                    else {
                        tree->left = pnext->right;
                        pnext->right = tree;
                        ptr->right = pnext->left;
                        pnext->left = ptr;
                        if (pnext->right != NULL) {
                            pnext->balance = 1;
                            tree->balance = 0;
                            ptr->balance = 1;
                        }
                        else {
                            pnext->balance = 0;
                            tree->balance = -1;
                            ptr->balance = 1;
                        }
                        tree = pnext;
                    }
                }
                else { // ptr->balance == -1
                    pnext = ptr->right;
                    tree->left = pnext->right;
                    pnext->right = tree;
                    ptr->right = pnext->left;
                    pnext->left = ptr;
                    if (pnext->balance == -1) {
                        pnext->balance = 0;
                        tree->balance = 0;
                        ptr->balance = 1;
                    }
                    else if (pnext->balance == 1) {
                        pnext->balance = 0;
                        tree->balance = -1;
                        ptr->balance = 0;
                    }
                    else {
                        pnext->balance = 0;
                        tree->balance = 0;
                        ptr->balance = 0;
                    }
                    isKeyFound = FALSE;
                    tree = pnext;
                }
                break;
            }
        }
        printf("after switch tree = %d, balance = %d \n", tree->key, tree->balance);
    }
    else {
        if (tree->left && tree->right) {
            ptr = findLargestElement(tree->left);
            tree->key = ptr->key;
            tree->left = deleteElement(tree->left, ptr->key, isKeyFound);
        }
        else {
            ptr = tree;
            if (tree->left == NULL && tree->right == NULL) {
                tree = NULL;
            }
            else if (tree->left != NULL) {
                tree = tree->left;  // change balance here
            }
            else {
                tree = tree->right;
            }
            free(ptr);
            tree = NULL;
            ptr = NULL;
        }
    }
    
    return tree;
}

struct node* insert(int data, struct node* tree, bool* isKeyFound) {
    struct node* aptr, * bptr;
    if (tree == NULL) {
        tree = (struct node*)malloc(sizeof(struct node));
        tree->key = data;
        tree->left = NULL;
        tree->right = NULL;
        tree->balance = 0;
        *isKeyFound = TRUE;
        return tree;
    }
    if (data < tree->key) {
        tree->left = insert(data, tree->left, isKeyFound);;
        if (*isKeyFound == TRUE) {
            switch (tree->balance) {
            case -1:
                tree->balance = 0;
                *isKeyFound = FALSE;
                break;
            case 0:
                tree->balance = 1;
                break;
            case 1:
                aptr = tree->left;
                if (aptr->balance == 1) {
                    tree->left = aptr->right;
                    aptr->right = tree;
                    tree->balance = 0;
                    aptr->balance = 0;
                    tree = aptr;
                }
                else {
                    bptr = aptr->right;
                    aptr->right = bptr->left;
                    bptr->left = aptr;
                    tree->left = bptr->right;
                    bptr->right = tree;
                    if (bptr->balance == 1) {
                        tree->balance = -1;
                    }
                    else {
                        tree->balance = 0;
                    }
                    if (bptr->balance == -1) {
                        aptr->balance = 1;
                    }
                    else {
                        aptr->balance = 0;
                    }
                    bptr->balance = 0;
                    tree = bptr;
                }
                *isKeyFound = FALSE;
            }
        }
    }
    else if (data > tree->key) {
        tree->right = insert(data, tree->right, isKeyFound);
        if (*isKeyFound == TRUE) {
            switch (tree->balance) {
            case 1:
                tree->balance = 0;
                *isKeyFound = FALSE;
                break;
            case 0:
                tree->balance = -1;
                break;
            case -1:
                aptr = tree->right;
                if (aptr->balance == -1) {
                    tree->right = aptr->left;
                    aptr->left = tree;
                    tree->balance = 0;
                    aptr->balance = 0;
                    tree = aptr;
                }
                else {
                    bptr = aptr->left;
                    aptr->left = bptr->right;
                    bptr->right = aptr;
                    tree->right = bptr->left;
                    bptr->left = tree;
                    if (bptr->balance == -1) {
                        tree->balance = 1;
                    }
                    else {
                        tree->balance = 0;
                    }
                    if (bptr->balance == 1) {
                        aptr->balance = -1;
                    }
                    else {
                        aptr->balance = 0;
                    }
                    bptr->balance = 0;
                    tree = bptr;
                }
                *isKeyFound = FALSE;
            }
        }
    }
    return tree;
}

void display(struct node* tree, int level) {
    int i;
    if (tree != NULL) {
        display(tree->right, level + 1);
        printf("\n");
        for (i = 0; i < level; i++) {
            printf(" ");
        }
        printf("%d ", tree->key);
        display(tree->left, level + 1);
    }
}

void inorder(struct node* tree) {
    if (tree != NULL) {
        inorder(tree->left);
        printf("%d ", tree->key);
        inorder(tree->right);
    }
}

int size(struct node* tree) {
    if (tree == NULL) {
        return 0;
    }
    else {
        return (size(tree->left) + 1 + size(tree->right));
    }
}

#include <limits.h>

static unsigned int mylog2(unsigned int val) {
    if (val == 0) return UINT_MAX;
    if (val == 1) return 0;
    unsigned int ret = 0;
    while (val > 1) {
        val >>= 1;
        ret++;
    }
    return ret;
}

int myhgt = 1;
void printInorder(struct node* tree, int hgt) {

    if (tree != NULL) {
        printInorder(tree->left, hgt);
        printf("\n the space is %d \n", myhgt);
        printf("\n");
        for (int i = 0; i < myhgt; i++) {
            printf(" ");
        }
        if (myhgt < hgt * 5) {
            myhgt *= 5;
        }
        else {
            myhgt /= 5;
        }
        printf("%d", tree->key);
        printInorder(tree->right, hgt);
    }
}

void printPreorder(struct node* node, int hgt)
{
    if (node == NULL)
        return;

    printf("\n");
    for (int i = 0; i < hgt * 2; i++) {
        printf(" ");
    }
    printf("%d ", node->key);

    printPreorder(node->left, hgt - 1);

    printPreorder(node->right, hgt - 1);
}

void readTree(struct node* myTree) {
    if (myTree == NULL) {
        return;
    }
    // k++;
    if (myTree->left != NULL) {
        readTree(myTree->left);
    }
    if (myTree->right) {
        readTree(myTree->right);
    }
}


void printTree(struct node* myTree, int* deep) {

    if (myTree == NULL) {
        return;
    }
    if (myTree->left != NULL) {
        printTree(myTree->left, deep);
    }
    for (int j = 0; j <= findHeight(myTree, myTree->key); j++) {
        printf("         ");
    }
    printf(">");
    printf("[%d]-%d\n\n", myTree->key, findHeight(myTree, myTree->key));
    if (myTree->right != NULL) {
        printTree(myTree->right, deep);
    }
}

int dep = 0;
int treeDepth(struct node* tree, int data, int* deep) {
    if (tree == NULL) {
        return -1;
    }
    *deep = *deep + 1;
    if (data < tree->key) {
        treeDepth(tree->left, data, deep);
    }
    else if (data > tree->key) {
        treeDepth(tree->right, data, deep);
    }
    return *deep - 1;
}

int main() {
    bool isKeyFound, tmp;
    int data, num, deep = 0;
    struct node* root = NULL;

    root = insert(45, root, &tmp);
    printTree(root, &deep);
    root = insert(36, root, &tmp);
    printTree(root, &deep);
    root = insert(63, root, &tmp);
    printTree(root, &deep);
    root = insert(27, root, &tmp);
    printTree(root, &deep);
    root = insert(39, root, &tmp);
    printTree(root, &deep);
    root = insert(72, root, &tmp);
    printTree(root, &deep);
    root = insert(37, root, &tmp);
    printTree(root, &deep);
    root = insert(41, root, &tmp);

    printf("\nThe size of the tree = %d \n", size(root));
    printTree(root, &deep);

    int asize = size(root);
    int height = cbrt(asize) + 1;
    int hg = mylog2(asize);
    //printf("\n\n ############## Inorder print below: \n");
    //printInorder(root, hg);
    //readTree(root);

    printf("\n1.Insert\n");
    printf("2.Display\n");
    printf("3.Find the largest\n"); // Find the largest elemnt.
    printf("4.Deleting the largest element\n");
    printf("5.Quit\n");
    printf("Enter your option : ");
    scanf("%d", &num);
    while (num != 5)
    {
        switch (num)
        {
        case 1:
            printf("Enter the value to be inserted : ");
            scanf("%d", &data);
            if (search(root, data) == NULL)
                root = insert(data, root, &isKeyFound);
            else
                printf("Duplicate value ignored\n");
            break;
        case 2:
            printf("Tree is :\n");
            //display(root, 1);
            printTree(root, &deep);
            printf("\n\n");
            printf("Inorder Traversal is : ");
            inorder(root);
            printf("\n");
            break;
        case 3:
            printf("\nThe largest number is: ");
            root = findLargestElement(root);
            printf("%d", findLargestElement(root)->key);
            break;
        case 4:
            printf("\nEnter a number you want delete:");
            scanf("%d", &data);
            root = deleteElement(root, data, &tmp);
            break;
        case 5:
            exit(1);
        default:
            printf("Wrong option\n");
        }

        readTree(root);

        printf("\n1.Insert\n");
        printf("2.Display\n");
        printf("3.Find the largest\n"); // Find the largest elemnt.
        printf("4. Deleting the largest element\n");
        printf("5.Quit\n");
        printf("Enter your option : ");
        scanf("%d", &num);
    }


}



